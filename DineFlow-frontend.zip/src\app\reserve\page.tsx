import { CalendarDays, Clock, Users } from "lucide-react";
import { AppNav, Card, PageHeader } from "@/components/ui/brand";
import { tables } from "@/lib/data";

export default function ReservePage() {
  return (
    <main className="min-h-screen bg-[var(--cream)]">
      <AppNav />
      <section className="mx-auto max-w-7xl px-5 py-14 md:px-8">
        <PageHeader eyebrow="Smart reservations" title="Grab a table without phone calls" copy="A frontend reservation flow that shows table fit, preferred time, guest count, and confirmation states." />
        <div className="mt-12 grid gap-6 lg:grid-cols-[0.9fr_1.1fr]">
          <Card className="bg-white p-6">
            <h2 className="font-serif text-3xl font-bold">Reserve your spot</h2>
            <div className="mt-6 grid gap-4">
              <label><span className="text-sm font-bold">Name</span><input className="mt-2 h-12 w-full rounded-[8px] border border-[#d7c9b5] bg-[#fcfaf6] px-4 outline-none" placeholder="Aarav Sharma" /></label>
              <label><span className="text-sm font-bold">Phone</span><input className="mt-2 h-12 w-full rounded-[8px] border border-[#d7c9b5] bg-[#fcfaf6] px-4 outline-none" placeholder="+91 98765 43210" /></label>
              <div className="grid gap-4 sm:grid-cols-3">
                <label><span className="text-sm font-bold">Date</span><div className="mt-2 flex h-12 items-center gap-2 rounded-[8px] border border-[#d7c9b5] bg-[#fcfaf6] px-4"><CalendarDays size={16} /> Today</div></label>
                <label><span className="text-sm font-bold">Time</span><div className="mt-2 flex h-12 items-center gap-2 rounded-[8px] border border-[#d7c9b5] bg-[#fcfaf6] px-4"><Clock size={16} /> 8:30 PM</div></label>
                <label><span className="text-sm font-bold">Guests</span><div className="mt-2 flex h-12 items-center gap-2 rounded-[8px] border border-[#d7c9b5] bg-[#fcfaf6] px-4"><Users size={16} /> 4</div></label>
              </div>
              <button className="h-12 rounded-full bg-[var(--terracotta)] font-bold text-white">Confirm reservation</button>
            </div>
          </Card>
          <Card className="p-6">
            <h2 className="font-serif text-3xl font-bold">Available floor plan</h2>
            <div className="mt-6 grid grid-cols-2 gap-3 md:grid-cols-4">
              {tables.slice(0, 12).map((table) => (
                <button key={table.id} className={`rounded-[8px] p-4 text-left text-sm font-bold ${
                  table.status === "available" ? "bg-[#eaf2e5] text-[#4f7d52]" :
                  table.status === "reserved" ? "bg-[#fbf0cf] text-[#a07012]" :
                  table.status === "cleaning" ? "bg-[#ece7df] text-[#8a7f71]" :
                  "bg-[#f8ddd5] text-[#b24428]"
                }`}>
                  <span className="block text-lg">{table.id}</span>
                  <span className="capitalize">{table.status}</span>
                  <span className="mt-2 block text-xs text-[var(--muted)]">Seats {table.capacity}</span>
                </button>
              ))}
            </div>
          </Card>
        </div>
      </section>
    </main>
  );
}
