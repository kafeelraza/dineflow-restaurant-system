import { AlertTriangle, Plus } from "lucide-react";
import { DashboardShell, InventoryBars } from "@/components/dashboard/dashboard-widgets";
import { inventory } from "@/lib/data";

export default function InventoryPage() {
  return (
    <DashboardShell title="Inventory control" subtitle="Stock levels, reorder thresholds, supplier context, and low-stock actions.">
      <div className="grid gap-6 xl:grid-cols-[1fr_0.85fr]">
        <div className="rounded-[8px] border border-[#eadfce] bg-white p-5">
          <div className="mb-5 flex items-center justify-between">
            <h2 className="font-serif text-2xl font-bold">Stock table</h2>
            <button className="flex h-10 items-center gap-2 rounded-full bg-[var(--terracotta)] px-4 text-sm font-bold text-white"><Plus size={16} /> Add item</button>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full min-w-[680px] text-left text-sm">
              <thead className="text-[var(--muted)]"><tr className="border-b border-[#eadfce]"><th className="py-3">Item</th><th>Stock</th><th>Threshold</th><th>Supplier</th><th>AI note</th></tr></thead>
              <tbody>
                {inventory.map((row) => {
                  const low = row.stock < row.threshold;
                  return (
                    <tr key={row.item} className="border-b border-[#eadfce]">
                      <td className="py-4 font-bold">{low && <AlertTriangle className="mr-2 inline text-[var(--terracotta)]" size={16} />}{row.item}</td>
                      <td>{row.stock} {row.unit}</td>
                      <td>{row.threshold} {row.unit}</td>
                      <td>{row.supplier}</td>
                      <td className={low ? "font-bold text-[var(--terracotta)]" : "text-[var(--muted)]"}>{row.trend}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
        <InventoryBars />
      </div>
    </DashboardShell>
  );
}
