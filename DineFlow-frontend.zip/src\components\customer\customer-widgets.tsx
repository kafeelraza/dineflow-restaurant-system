"use client";

import Image from "next/image";
import { useMemo, useState } from "react";
import { Bot, Check, MessageCircle, Minus, Plus, ShoppingBag, Sparkles, X } from "lucide-react";
import { categories, formatRs, menuItems } from "@/lib/data";

export function MenuExperience() {
  const [active, setActive] = useState("Chef picks");
  const [cart, setCart] = useState<Record<string, number>>({ "paneer-tikka": 1, "nimbu-soda": 2 });
  const [cartOpen, setCartOpen] = useState(false);
  const [chatOpen, setChatOpen] = useState(false);

  const filtered = active === "Chef picks" ? menuItems : menuItems.filter((item) => item.category === active);
  const cartLines = menuItems.filter((item) => cart[item.id]);
  const subtotal = cartLines.reduce((sum, item) => sum + item.price * cart[item.id], 0);
  const itemCount = Object.values(cart).reduce((sum, qty) => sum + qty, 0);

  function updateCart(id: string, delta: number) {
    setCart((current) => {
      const nextQty = Math.max(0, (current[id] ?? 0) + delta);
      const next = { ...current, [id]: nextQty };
      if (!nextQty) delete next[id];
      return next;
    });
  }

  return (
    <>
      <div className="flex gap-3 overflow-x-auto pb-3">
        {categories.map((tab) => (
          <button
            key={tab}
            onClick={() => setActive(tab)}
            className={`shrink-0 rounded-full px-5 py-3 text-sm font-bold transition ${active === tab ? "bg-[var(--ink)] text-white" : "border border-[#d7c9b5] bg-[#fcfaf6] text-[var(--ink)] hover:bg-white"}`}
          >
            {tab}
          </button>
        ))}
      </div>

      <div className="mt-8 grid gap-6 md:grid-cols-2 xl:grid-cols-3">
        {filtered.map((item) => (
          <article key={item.id} className={`overflow-hidden rounded-[8px] bg-white shadow-[0_18px_45px_rgba(43,38,33,0.08)] ${!item.isAvailable ? "opacity-70" : ""}`}>
            <div className="relative h-48">
              <Image src={item.img} alt={item.name} fill sizes="(min-width: 1280px) 33vw, (min-width: 768px) 50vw, 100vw" className="object-cover" />
              {!item.isAvailable && <span className="absolute right-4 top-4 rounded-full bg-[#2b2621] px-3 py-1 text-xs font-bold text-white">Sold out</span>}
            </div>
            <div className="p-5">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <div className="flex flex-wrap items-center gap-2">
                    <span className={`h-3 w-3 rounded-full border ${item.isVeg ? "border-[#6B9B6E]" : "border-[#C1502E]"}`}>
                      <span className={`mx-auto mt-[3px] block h-1.5 w-1.5 rounded-full ${item.isVeg ? "bg-[#6B9B6E]" : "bg-[#C1502E]"}`} />
                    </span>
                    {item.tags.map((tag) => <span key={tag} className="text-xs font-bold uppercase tracking-[0.12em] text-[var(--sage)]">{tag}</span>)}
                  </div>
                  <h2 className="mt-2 text-xl font-bold">{item.name}</h2>
                </div>
                <p className="font-mono text-lg font-bold text-[var(--terracotta)]">{formatRs(item.price)}</p>
              </div>
              <p className="mt-3 min-h-12 text-sm leading-6 text-[var(--muted)]">{item.description}</p>
              <div className="mt-5 flex items-center justify-between gap-3">
                <span className="rounded-full bg-[#f3eee5] px-3 py-2 text-xs font-bold text-[var(--muted)]">{item.prepTime} min prep</span>
                {cart[item.id] ? (
                  <div className="flex h-11 items-center overflow-hidden rounded-full border border-[#d7c9b5] bg-[#fcfaf6]">
                    <button className="px-3" onClick={() => updateCart(item.id, -1)}><Minus size={16} /></button>
                    <span className="w-8 text-center font-bold">{cart[item.id]}</span>
                    <button className="px-3" onClick={() => updateCart(item.id, 1)}><Plus size={16} /></button>
                  </div>
                ) : (
                  <button disabled={!item.isAvailable} onClick={() => updateCart(item.id, 1)} className="flex h-11 items-center gap-2 rounded-full bg-[var(--terracotta)] px-5 text-sm font-bold text-white disabled:cursor-not-allowed disabled:bg-[#cbbfb0]">
                    <Plus size={16} /> Add
                  </button>
                )}
              </div>
            </div>
          </article>
        ))}
      </div>

      <button onClick={() => setChatOpen(true)} className="fixed bottom-5 left-5 z-50 flex h-14 w-14 items-center justify-center rounded-full bg-[var(--sage)] text-white shadow-[0_16px_32px_rgba(43,38,33,0.22)]" aria-label="Open AI assistant">
        <MessageCircle />
      </button>
      <button onClick={() => setCartOpen(true)} className="fixed bottom-5 right-5 z-50 flex h-14 items-center gap-3 rounded-full bg-[var(--ink)] px-5 text-white shadow-[0_16px_32px_rgba(43,38,33,0.22)]" aria-label="Open cart">
        <ShoppingBag /> <span className="font-bold">{itemCount}</span>
      </button>

      {cartOpen && (
        <div className="fixed inset-0 z-[60] bg-black/25 p-4 backdrop-blur-sm" onClick={() => setCartOpen(false)}>
          <aside className="ml-auto flex h-full max-w-md flex-col rounded-[8px] bg-[#fcfaf6] p-5 shadow-2xl" onClick={(event) => event.stopPropagation()}>
            <div className="flex items-center justify-between border-b border-[#eadfce] pb-4">
              <div>
                <p className="text-sm font-bold uppercase tracking-[0.15em] text-[var(--terracotta)]">Table T07</p>
                <h2 className="font-serif text-3xl font-bold">Your order</h2>
              </div>
              <button onClick={() => setCartOpen(false)} className="rounded-full border border-[#d7c9b5] p-2"><X size={18} /></button>
            </div>
            <div className="flex-1 space-y-4 overflow-auto py-5">
              {cartLines.map((item) => (
                <div key={item.id} className="flex items-center justify-between gap-3 rounded-[8px] bg-white p-4">
                  <div>
                    <p className="font-bold">{item.name}</p>
                    <p className="text-sm text-[var(--muted)]">{cart[item.id]} x {formatRs(item.price)}</p>
                  </div>
                  <p className="font-mono font-bold">{formatRs(cart[item.id] * item.price)}</p>
                </div>
              ))}
            </div>
            <div className="border-t border-[#eadfce] pt-4">
              <div className="flex justify-between text-lg font-bold"><span>Subtotal</span><span>{formatRs(subtotal)}</span></div>
              <a href="/order/demo" className="mt-4 flex h-12 w-full items-center justify-center rounded-full bg-[var(--terracotta)] font-bold text-white">Place order</a>
            </div>
          </aside>
        </div>
      )}

      {chatOpen && <ChatPanel onClose={() => setChatOpen(false)} />}
    </>
  );
}

function ChatPanel({ onClose }: { onClose: () => void }) {
  const [messages, setMessages] = useState([
    { from: "bot", text: "Hi, I can suggest dishes, explain allergens, or estimate prep time." },
    { from: "user", text: "Something spicy and vegetarian?" },
    { from: "bot", text: "Try Charred Paneer Tikka. It is spicy, vegetarian, and usually ready in about 10 minutes." },
  ]);
  const [text, setText] = useState("");

  const quickSuggestion = useMemo(() => "Add Paneer Tikka + Nimbu Soda combo", []);

  return (
    <div className="fixed inset-0 z-[70] bg-black/25 p-4 backdrop-blur-sm">
      <section className="ml-auto flex h-full max-w-md flex-col rounded-[8px] bg-[#fcfaf6] shadow-2xl">
        <header className="flex items-center justify-between border-b border-[#eadfce] p-5">
          <div className="flex items-center gap-3">
            <span className="flex h-11 w-11 items-center justify-center rounded-full bg-[#f5e1d4] text-[var(--terracotta)]"><Bot /></span>
            <div><p className="font-bold">AI dining assistant</p><p className="text-sm text-[var(--muted)]">Frontend mock, Gemini-ready</p></div>
          </div>
          <button onClick={onClose} className="rounded-full border border-[#d7c9b5] p-2"><X size={18} /></button>
        </header>
        <div className="flex-1 space-y-4 overflow-auto p-5">
          {messages.map((message, index) => (
            <div key={index} className={`max-w-[86%] rounded-[8px] p-4 text-sm leading-6 ${message.from === "bot" ? "bg-white text-[var(--ink)]" : "ml-auto bg-[var(--terracotta)] text-white"}`}>{message.text}</div>
          ))}
          <button className="inline-flex items-center gap-2 rounded-full bg-[#eaf2e5] px-4 py-2 text-sm font-bold text-[var(--sage)]"><Sparkles size={16} /> {quickSuggestion}</button>
        </div>
        <form
          className="flex gap-2 border-t border-[#eadfce] p-4"
          onSubmit={(event) => {
            event.preventDefault();
            if (!text.trim()) return;
            setMessages((current) => [...current, { from: "user", text }, { from: "bot", text: "Nice choice. Based on live kitchen load, I would suggest Saffron Butter Bowl with Nimbu Soda. Estimated prep is 14 minutes." }]);
            setText("");
          }}
        >
          <input value={text} onChange={(event) => setText(event.target.value)} placeholder="Ask about dishes..." className="min-w-0 flex-1 rounded-full border border-[#d7c9b5] bg-white px-4 outline-none" />
          <button className="rounded-full bg-[var(--ink)] px-5 font-bold text-white">Send</button>
        </form>
      </section>
    </div>
  );
}

export function OrderStepper({ status = "preparing" }: { status?: string }) {
  const steps = ["placed", "confirmed", "preparing", "ready", "served"];
  const active = Math.max(0, steps.indexOf(status));

  return (
    <div className="grid gap-4 md:grid-cols-5">
      {steps.map((step, index) => {
        const done = index <= active;
        return (
          <div key={step} className={`rounded-[8px] border p-4 ${done ? "border-[var(--terracotta)] bg-[#f8eadf]" : "border-[#eadfce] bg-[#fcfaf6]"}`}>
            <span className={`flex h-9 w-9 items-center justify-center rounded-full ${done ? "bg-[var(--terracotta)] text-white" : "bg-[#eadfce] text-[var(--muted)]"}`}>
              {done ? <Check size={16} /> : index + 1}
            </span>
            <p className="mt-4 text-sm font-bold capitalize">{step}</p>
          </div>
        );
      })}
    </div>
  );
}
