import { CalendarPlus } from "lucide-react";
import { DashboardShell } from "@/components/dashboard/dashboard-widgets";
import { staff } from "@/lib/data";

export default function StaffPage() {
  return (
    <DashboardShell title="Staff coordination" subtitle="Shift roster, current load, and role assignment views for smoother service.">
      <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-4">
        {staff.map((member) => (
          <article key={member.name} className="rounded-[8px] border border-[#eadfce] bg-white p-5">
            <span className="rounded-full bg-[#eaf2e5] px-3 py-1 text-xs font-bold text-[var(--sage)]">{member.status}</span>
            <h2 className="mt-5 font-serif text-2xl font-bold">{member.name}</h2>
            <p className="text-sm font-bold text-[var(--terracotta)]">{member.role}</p>
            <div className="mt-5 space-y-2 text-sm text-[var(--muted)]">
              <p><b className="text-[var(--ink)]">Shift:</b> {member.shift}</p>
              <p><b className="text-[var(--ink)]">Load:</b> {member.load}</p>
            </div>
            <button className="mt-5 flex h-10 w-full items-center justify-center gap-2 rounded-full border border-[#d7c9b5] bg-[#fcfaf6] text-sm font-bold"><CalendarPlus size={16} /> Edit shift</button>
          </article>
        ))}
      </div>
    </DashboardShell>
  );
}
