"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  BarChart3,
  Bell,
  Bot,
  ChefHat,
  CreditCard,
  LayoutDashboard,
  Package,
  Search,
  Table2,
  Users,
  Utensils,
} from "lucide-react";
import { aiInsights, formatRs, inventory, orders, tables } from "@/lib/data";

const nav = [
  { href: "/dashboard", label: "Overview", icon: LayoutDashboard },
  { href: "/dashboard/orders", label: "Orders", icon: ChefHat },
  { href: "/dashboard/tables", label: "Tables", icon: Table2 },
  { href: "/dashboard/inventory", label: "Inventory", icon: Package },
  { href: "/dashboard/staff", label: "Staff", icon: Users },
  { href: "/dashboard/customers", label: "Customers", icon: CreditCard },
  { href: "/dashboard/analytics", label: "Analytics", icon: BarChart3 },
  { href: "/dashboard/ai", label: "AI Ops", icon: Bot },
];

export function DashboardShell({ children, title, subtitle }: { children: React.ReactNode; title: string; subtitle: string }) {
  const pathname = usePathname();

  return (
    <main className="min-h-screen bg-[#2b2621] p-3 text-[var(--ink)] md:p-5">
      <div className="grid min-h-[calc(100vh-24px)] overflow-hidden rounded-[8px] bg-[#fcfaf6] lg:grid-cols-[250px_1fr]">
        <aside className="hidden border-r border-[#eadfce] bg-[#f5efe5] p-5 lg:block">
          <Link href="/" className="mb-8 flex items-center gap-3">
            <Utensils className="text-[var(--terracotta)]" />
            <span className="font-serif text-2xl font-black">DineFlow</span>
          </Link>
          {nav.map((item) => {
            const active = pathname === item.href;
            const Icon = item.icon;
            return (
              <Link key={item.href} href={item.href} className={`mb-2 flex items-center gap-3 rounded-[8px] px-4 py-3 text-sm font-bold ${active ? "bg-white text-[var(--terracotta)] shadow-sm" : "text-[var(--muted)] hover:bg-white/60"}`}>
                <Icon size={18} /> {item.label}
              </Link>
            );
          })}
        </aside>
        <section className="min-w-0 p-5 md:p-7">
          <header className="flex flex-col justify-between gap-4 border-b border-[#eadfce] pb-5 md:flex-row md:items-center">
            <div>
              <p className="text-sm font-semibold uppercase tracking-[0.16em] text-[var(--terracotta)]">Admin role: owner</p>
              <h1 className="font-serif text-4xl font-black">{title}</h1>
              <p className="mt-1 text-sm text-[var(--muted)]">{subtitle}</p>
            </div>
            <div className="flex items-center gap-3">
              <div className="hidden h-11 items-center gap-2 rounded-full border border-[#d7c9b5] bg-white px-4 text-sm text-[var(--muted)] sm:flex">
                <Search size={16} /> Search operations
              </div>
              <Link href="/notifications" className="relative flex h-11 w-11 items-center justify-center rounded-full bg-white text-[var(--ink)]">
                <Bell size={18} />
                <span className="absolute right-1 top-1 h-2.5 w-2.5 rounded-full bg-[var(--terracotta)]" />
              </Link>
            </div>
          </header>
          <div className="mt-6 lg:hidden">
            <div className="flex gap-2 overflow-x-auto pb-2">
              {nav.map((item) => <Link key={item.href} href={item.href} className="shrink-0 rounded-full border border-[#d7c9b5] bg-white px-4 py-2 text-xs font-bold">{item.label}</Link>)}
            </div>
          </div>
          <div className="mt-6">{children}</div>
        </section>
      </div>
    </main>
  );
}

export function StatCard({ label, value, note }: { label: string; value: string; note: string }) {
  return (
    <div className="rounded-[8px] border border-[#eadfce] bg-white p-4">
      <p className="text-sm text-[var(--muted)]">{label}</p>
      <div className="mt-3 flex items-end justify-between gap-4">
        <p className="font-mono text-3xl font-bold text-[var(--ink)]">{value}</p>
        <svg viewBox="0 0 80 28" className="h-8 w-20 text-[var(--sage)]" fill="none">
          <path d="M2 24c10-2 12-14 22-11 8 2 8 9 18 6 9-3 11-16 21-15 8 1 10 8 15 7" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
        </svg>
      </div>
      <p className="mt-2 text-xs font-semibold text-[var(--sage)]">{note}</p>
    </div>
  );
}

export function OverviewDashboard() {
  return (
    <div className="space-y-5">
      <div className="grid gap-4 md:grid-cols-4">
        <StatCard label="Today's revenue" value="Rs. 42.8k" note="+18% vs yesterday" />
        <StatCard label="Active orders" value="24" note="7 need attention" />
        <StatCard label="Occupancy" value="78%" note="Peak in 35 min" />
        <StatCard label="Low stock" value="06" note="Paneer, mint, cream" />
      </div>
      <div className="grid gap-5 xl:grid-cols-[1.2fr_0.8fr]">
        <LiveOrders />
        <AIInsightCard />
      </div>
      <div className="grid gap-5 xl:grid-cols-[0.8fr_1.2fr]">
        <TableGrid compact />
        <InventoryBars />
      </div>
    </div>
  );
}

export function LiveOrders() {
  return (
    <div className="rounded-[8px] border border-[#eadfce] bg-white p-5">
      <div className="mb-4 flex items-center justify-between">
        <h2 className="font-serif text-2xl font-bold">Live orders</h2>
        <span className="rounded-full bg-[#f8eadf] px-3 py-1 text-xs font-bold text-[var(--terracotta)]">Realtime mock</span>
      </div>
      <div className="space-y-3">
        {orders.map((order) => (
          <div key={order.id} className="grid gap-3 rounded-[8px] border border-[#eadfce] p-4 sm:grid-cols-[76px_1fr_74px_112px] sm:items-center">
            <p className="font-mono font-bold">#{order.id}</p>
            <p className="text-sm text-[var(--muted)]"><span className="font-bold text-[var(--ink)]">{order.table}</span> - {order.items.join(", ")}</p>
            <p className="font-mono text-sm font-bold text-[var(--sage)]">{order.eta ? `${order.eta}m` : "Ready"}</p>
            <button className="rounded-full bg-[#f3eee5] px-3 py-2 text-xs font-bold capitalize">{order.status}</button>
          </div>
        ))}
      </div>
    </div>
  );
}

export function AIInsightCard() {
  return (
    <div className="rounded-[8px] border border-[#eadfce] bg-white p-5">
      <h2 className="font-serif text-2xl font-bold">AI daily digest</h2>
      <div className="mt-4 space-y-3 text-sm leading-6 text-[var(--muted)]">
        {aiInsights.map((insight) => (
          <p key={insight}><Bot className="mr-2 inline text-[var(--terracotta)]" size={16} />{insight}</p>
        ))}
      </div>
      <Link href="/dashboard/ai" className="mt-5 inline-flex rounded-full bg-[var(--ink)] px-5 py-3 text-sm font-bold text-white">Open AI ops</Link>
    </div>
  );
}

export function TableGrid({ compact = false }: { compact?: boolean }) {
  return (
    <div className="rounded-[8px] border border-[#eadfce] bg-white p-5">
      <h2 className="font-serif text-2xl font-bold">Floor plan</h2>
      <div className={`mt-5 grid gap-2 ${compact ? "grid-cols-4" : "grid-cols-2 md:grid-cols-4"}`}>
        {tables.map((table) => (
          <button key={table.id} className={`rounded-[8px] p-4 text-left text-xs font-bold ${
            table.status === "available" ? "bg-[#eaf2e5] text-[#4f7d52]" :
            table.status === "reserved" ? "bg-[#fbf0cf] text-[#a07012]" :
            table.status === "cleaning" ? "bg-[#ece7df] text-[#8a7f71]" :
            "bg-[#f8ddd5] text-[#b24428]"
          }`}>
            <span className="block text-base">{table.id}</span>
            <span className="capitalize">{table.status}</span>
            {!compact && <span className="mt-2 block text-[var(--muted)]">Seats {table.capacity} - {table.server}</span>}
          </button>
        ))}
      </div>
    </div>
  );
}

export function InventoryBars() {
  return (
    <div className="rounded-[8px] border border-[#eadfce] bg-white p-5">
      <h2 className="font-serif text-2xl font-bold">Inventory watch</h2>
      <div className="mt-5 space-y-4">
        {inventory.map((row) => {
          const percent = Math.min(100, Math.round((row.stock / row.threshold) * 100));
          const low = row.stock < row.threshold;
          return (
            <div key={row.item}>
              <div className="mb-2 flex justify-between text-sm">
                <span className="font-bold">{row.item}</span>
                <span className={low ? "font-bold text-[var(--terracotta)]" : "text-[var(--muted)]"}>{row.stock} {row.unit} / min {row.threshold}</span>
              </div>
              <div className="h-3 overflow-hidden rounded-full bg-[#f3eee5]">
                <div className={`h-full rounded-full ${low ? "bg-[var(--terracotta)]" : "bg-[var(--sage)]"}`} style={{ width: `${percent}%` }} />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

export function RevenueChart() {
  const values = [18, 24, 20, 32, 28, 45, 42, 58, 51, 68, 76, 72];
  const max = Math.max(...values);
  return (
    <div className="rounded-[8px] border border-[#eadfce] bg-white p-5">
      <div className="flex items-center justify-between">
        <h2 className="font-serif text-2xl font-bold">Sales pulse</h2>
        <p className="font-mono font-bold text-[var(--terracotta)]">{formatRs(42800)}</p>
      </div>
      <div className="mt-8 flex h-56 items-end gap-3">
        {values.map((value, index) => (
          <div key={index} className="flex flex-1 flex-col items-center gap-2">
            <div className="w-full rounded-t-[8px] bg-[var(--terracotta)]" style={{ height: `${(value / max) * 100}%`, opacity: 0.45 + index / 24 }} />
            <span className="text-xs text-[var(--muted)]">{index + 11}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
