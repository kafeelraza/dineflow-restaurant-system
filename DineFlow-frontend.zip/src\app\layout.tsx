import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "DineFlow | Smart Restaurant Management",
  description:
    "A warm, AI-assisted restaurant operations UI for customer ordering, live kitchen status, reservations, and owner insights.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="h-full antialiased">
      <body
        className="min-h-full"
        style={
          {
            "--font-body": 'Inter, "Segoe UI", Arial, sans-serif',
            "--font-display": 'Georgia, "Times New Roman", serif',
            "--font-numeric": '"Space Grotesk", "Segoe UI", monospace',
          } as React.CSSProperties
        }
      >
        {children}
      </body>
    </html>
  );
}
