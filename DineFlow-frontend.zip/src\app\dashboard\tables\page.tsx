"use client";

import { useState } from "react";
import { DashboardShell } from "@/components/dashboard/dashboard-widgets";
import { tables, type TableStatus } from "@/lib/data";

const cycle: TableStatus[] = ["available", "occupied", "reserved", "cleaning"];

export default function TablesPage() {
  const [localTables, setLocalTables] = useState(tables);

  return (
    <DashboardShell title="Tables and queue" subtitle="Visual floor-plan grid for seating, reservation, cleaning, and occupancy management.">
      <div className="grid gap-6 lg:grid-cols-[1fr_320px]">
        <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
          {localTables.map((table) => (
            <button
              key={table.id}
              onClick={() => setLocalTables((current) => current.map((row) => row.id === table.id ? { ...row, status: cycle[(cycle.indexOf(row.status) + 1) % cycle.length] } : row))}
              className={`rounded-[8px] p-5 text-left font-bold transition hover:scale-[1.02] ${
                table.status === "available" ? "bg-[#eaf2e5] text-[#4f7d52]" :
                table.status === "reserved" ? "bg-[#fbf0cf] text-[#a07012]" :
                table.status === "cleaning" ? "bg-[#ece7df] text-[#8a7f71]" :
                "bg-[#f8ddd5] text-[#b24428]"
              }`}
            >
              <span className="block text-2xl">{table.id}</span>
              <span className="capitalize">{table.status}</span>
              <span className="mt-3 block text-xs text-[var(--muted)]">Seats {table.capacity} - {table.server}</span>
            </button>
          ))}
        </div>
        <aside className="rounded-[8px] border border-[#eadfce] bg-white p-5">
          <h2 className="font-serif text-2xl font-bold">Queue</h2>
          <div className="mt-4 space-y-3">
            {["Ananya - 2 guests - 12m wait", "Rohit - 5 guests - 18m wait", "Nora - 3 guests - patio preferred"].map((item) => (
              <div key={item} className="rounded-[8px] bg-[#fcfaf6] p-4 text-sm font-bold">{item}</div>
            ))}
          </div>
        </aside>
      </div>
    </DashboardShell>
  );
}
