"use client";

import { useState } from "react";
import { ArrowRight, Clock3 } from "lucide-react";
import { DashboardShell } from "@/components/dashboard/dashboard-widgets";
import { formatRs, orders, type OrderStatus } from "@/lib/data";

const columns: OrderStatus[] = ["placed", "confirmed", "preparing", "ready", "served"];

export default function OrdersPage() {
  const [localOrders, setLocalOrders] = useState(orders);

  function advance(id: string) {
    setLocalOrders((current) =>
      current.map((order) => {
        if (order.id !== id) return order;
        const next = columns[Math.min(columns.indexOf(order.status) + 1, columns.length - 1)];
        return { ...order, status: next };
      }),
    );
  }

  return (
    <DashboardShell title="Order command board" subtitle="Kitchen-friendly kanban with quick status movement and ETA visibility.">
      <div className="grid gap-4 xl:grid-cols-5">
        {columns.map((column) => (
          <section key={column} className="rounded-[8px] border border-[#eadfce] bg-white p-4">
            <h2 className="font-serif text-2xl font-bold capitalize">{column}</h2>
            <div className="mt-4 space-y-3">
              {localOrders.filter((order) => order.status === column).map((order) => (
                <article key={order.id} className="rounded-[8px] bg-[#fcfaf6] p-4">
                  <div className="flex justify-between gap-3">
                    <p className="font-mono font-bold">#{order.id}</p>
                    <span className="rounded-full bg-[#eaf2e5] px-2 py-1 text-xs font-bold text-[var(--sage)]">{order.table}</span>
                  </div>
                  <p className="mt-3 font-bold">{order.customer}</p>
                  <p className="mt-1 text-sm leading-6 text-[var(--muted)]">{order.items.join(", ")}</p>
                  <div className="mt-4 flex items-center justify-between">
                    <span className="flex items-center gap-1 text-xs font-bold text-[var(--terracotta)]"><Clock3 size={14} /> {order.eta ? `${order.eta}m` : "Ready"}</span>
                    <span className="font-mono text-sm font-bold">{formatRs(order.total)}</span>
                  </div>
                  <button onClick={() => advance(order.id)} className="mt-4 flex h-10 w-full items-center justify-center gap-2 rounded-full bg-[var(--ink)] text-sm font-bold text-white">
                    Move <ArrowRight size={15} />
                  </button>
                </article>
              ))}
            </div>
          </section>
        ))}
      </div>
    </DashboardShell>
  );
}
