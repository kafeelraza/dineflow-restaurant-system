import { Mail, ShieldCheck } from "lucide-react";
import { AppNav, ButtonLink, Card, RolePill } from "@/components/ui/brand";

export default function LoginPage() {
  return (
    <main className="min-h-screen bg-[var(--cream)]">
      <AppNav />
      <section className="mx-auto grid max-w-6xl gap-8 px-5 py-16 md:grid-cols-[0.9fr_1.1fr] md:px-8">
        <div className="self-center">
          <RolePill role="Silver story: auth UI" />
          <h1 className="mt-5 font-serif text-5xl font-black leading-tight">Secure entry for every restaurant role.</h1>
          <p className="mt-5 text-lg leading-8 text-[var(--muted)]">
            This frontend flow is ready for Supabase Auth: email/password, OTP verification, Google OAuth, and role-based routing for customer, staff, and admin.
          </p>
          <div className="mt-8 grid gap-3 sm:grid-cols-3">
            <ButtonLink href="/menu" variant="secondary">Customer demo</ButtonLink>
            <ButtonLink href="/dashboard/orders" variant="secondary">Staff demo</ButtonLink>
            <ButtonLink href="/dashboard" variant="secondary">Admin demo</ButtonLink>
          </div>
        </div>
        <Card className="bg-white p-6">
          <div className="mb-6">
            <p className="text-sm font-bold uppercase tracking-[0.16em] text-[var(--terracotta)]">Welcome back</p>
            <h2 className="mt-2 font-serif text-4xl font-bold">Login</h2>
          </div>
          <div className="space-y-4">
            <label className="block">
              <span className="text-sm font-bold">Email</span>
              <input className="mt-2 h-12 w-full rounded-[8px] border border-[#d7c9b5] bg-[#fcfaf6] px-4 outline-none focus:border-[var(--terracotta)]" placeholder="owner@dineflow.app" />
            </label>
            <label className="block">
              <span className="text-sm font-bold">Password</span>
              <input type="password" className="mt-2 h-12 w-full rounded-[8px] border border-[#d7c9b5] bg-[#fcfaf6] px-4 outline-none focus:border-[var(--terracotta)]" placeholder="••••••••" />
            </label>
            <div>
              <span className="text-sm font-bold">Choose role</span>
              <div className="mt-2 grid gap-2 sm:grid-cols-3">
                {["customer", "staff", "admin"].map((role) => <button key={role} className="rounded-full border border-[#d7c9b5] bg-[#fcfaf6] px-4 py-3 text-sm font-bold capitalize hover:bg-white">{role}</button>)}
              </div>
            </div>
            <button className="flex h-12 w-full items-center justify-center gap-2 rounded-full bg-[var(--terracotta)] font-bold text-white"><Mail size={18} /> Send OTP and login</button>
            <button className="flex h-12 w-full items-center justify-center gap-2 rounded-full border border-[#d7c9b5] bg-white font-bold text-[var(--ink)]"><ShieldCheck size={18} /> Continue with Google</button>
          </div>
          <div className="mt-6 rounded-[8px] bg-[#f8eadf] p-4 text-sm leading-6 text-[var(--ink)]">
            OTP preview: <b>428196</b>. Backend later will replace this with Supabase email verification.
          </div>
          <p className="mt-5 text-sm text-[var(--muted)]">New restaurant? <a href="/signup" className="font-bold text-[var(--terracotta)]">Create workspace</a></p>
        </Card>
      </section>
    </main>
  );
}
