import { CreditCard, Download, ReceiptText } from "lucide-react";
import { AppNav, Card, PageHeader } from "@/components/ui/brand";
import { formatRs } from "@/lib/data";

export default function BillingPage() {
  const subtotal = 520;
  const tax = 26;
  const discount = 50;
  const total = subtotal + tax - discount;

  return (
    <main className="min-h-screen bg-[var(--cream)]">
      <AppNav />
      <section className="mx-auto max-w-4xl px-5 py-14 md:px-8">
        <PageHeader eyebrow="Billing workflow" title="A bill that is ready when the table is" copy="Frontend bill preview with subtotal, tax, discount, payment state, and receipt actions." />
        <Card className="mx-auto mt-12 bg-white p-6">
          <div className="flex items-center justify-between border-b border-[#eadfce] pb-5">
            <div><p className="font-mono text-sm font-bold text-[var(--terracotta)]">BILL #B-1842</p><h2 className="font-serif text-3xl font-bold">Table T07</h2></div>
            <ReceiptText className="text-[var(--terracotta)]" size={34} />
          </div>
          <div className="mt-6 space-y-4">
            {[
              ["Charred Paneer Tikka", 280],
              ["House Nimbu Soda x2", 240],
            ].map(([name, price]) => (
              <div key={name as string} className="flex justify-between text-sm"><span>{name}</span><span className="font-mono font-bold">{formatRs(price as number)}</span></div>
            ))}
          </div>
          <div className="mt-6 space-y-3 border-t border-[#eadfce] pt-5">
            <div className="flex justify-between"><span>Subtotal</span><b>{formatRs(subtotal)}</b></div>
            <div className="flex justify-between text-[var(--muted)]"><span>GST</span><span>{formatRs(tax)}</span></div>
            <div className="flex justify-between text-[var(--sage)]"><span>Loyalty discount</span><span>-{formatRs(discount)}</span></div>
            <div className="flex justify-between border-t border-[#eadfce] pt-4 text-2xl font-black"><span>Total</span><span>{formatRs(total)}</span></div>
          </div>
          <div className="mt-6 grid gap-3 sm:grid-cols-2">
            <button className="flex h-12 items-center justify-center gap-2 rounded-full bg-[var(--terracotta)] font-bold text-white"><CreditCard size={18} /> Mark paid</button>
            <button className="flex h-12 items-center justify-center gap-2 rounded-full border border-[#d7c9b5] bg-[#fcfaf6] font-bold"><Download size={18} /> Download receipt</button>
          </div>
        </Card>
      </section>
    </main>
  );
}
