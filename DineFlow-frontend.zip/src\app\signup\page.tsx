import { BadgeCheck, KeyRound, Store } from "lucide-react";
import { AppNav, Card, RolePill } from "@/components/ui/brand";

export default function SignupPage() {
  return (
    <main className="min-h-screen bg-[var(--cream)]">
      <AppNav />
      <section className="mx-auto grid max-w-6xl gap-8 px-5 py-16 md:grid-cols-[1fr_0.95fr] md:px-8">
        <Card className="bg-white p-6">
          <RolePill role="workspace setup" />
          <h1 className="mt-4 font-serif text-4xl font-black">Create your restaurant workspace</h1>
          <div className="mt-6 grid gap-4">
            <label><span className="text-sm font-bold">Restaurant name</span><input className="mt-2 h-12 w-full rounded-[8px] border border-[#d7c9b5] bg-[#fcfaf6] px-4 outline-none" placeholder="Haven Table" /></label>
            <label><span className="text-sm font-bold">Owner email</span><input className="mt-2 h-12 w-full rounded-[8px] border border-[#d7c9b5] bg-[#fcfaf6] px-4 outline-none" placeholder="owner@restaurant.com" /></label>
            <label><span className="text-sm font-bold">Password</span><input type="password" className="mt-2 h-12 w-full rounded-[8px] border border-[#d7c9b5] bg-[#fcfaf6] px-4 outline-none" placeholder="Create password" /></label>
            <button className="flex h-12 items-center justify-center gap-2 rounded-full bg-[var(--terracotta)] font-bold text-white"><KeyRound size={18} /> Create with OTP verification</button>
            <button className="flex h-12 items-center justify-center gap-2 rounded-full border border-[#d7c9b5] bg-white font-bold"><BadgeCheck size={18} /> Sign up with Google</button>
          </div>
        </Card>
        <div className="self-center">
          <Store className="text-[var(--terracotta)]" size={42} />
          <h2 className="mt-5 font-serif text-5xl font-black leading-tight">One account. Three useful work modes.</h2>
          <div className="mt-6 space-y-3">
            {[
              ["Customer", "Scan menu, reserve, order, track status, pay bill."],
              ["Staff", "Move orders, manage tables, handle notifications."],
              ["Admin", "Control menu, inventory, staff, analytics, AI insights."],
            ].map(([role, copy]) => (
              <div key={role} className="rounded-[8px] border border-[#eadfce] bg-[#fcfaf6] p-4">
                <p className="font-bold">{role}</p>
                <p className="text-sm leading-6 text-[var(--muted)]">{copy}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </main>
  );
}
